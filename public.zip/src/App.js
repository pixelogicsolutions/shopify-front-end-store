import React, { useEffect } from "react"
import { BrowserRouter as Router, Route, Redirect } from "react-router-dom"
import Products from "./componet/Product"
import Cart from "./componet/Cart"
import Home from "./componet/Home"
import ProductView from "./componet/ProductView"
import { useShopify } from "./action/help/shopify.help"

export default function App (props)  {
	const {
		createShop,
		createCheckout,
		fetchProducts,
	//	 fetchCollection,
	} = useShopify()

	useEffect(() => {
		createShop()
		fetchProducts()
		createCheckout()
		// fetchCollection()
	}, [])

	return (
		<Router>
			<div id="App">
				<Route exact path="/" component={Home} />
				<Route path="/Home"  component={Home} />
				<Route path="/Home"  component={Products} />
				<Route path="/Product/:productId"  component={ProductView} />
				<Route path="/"  component={Cart} />
			</div>
		</Router>
	)
}


