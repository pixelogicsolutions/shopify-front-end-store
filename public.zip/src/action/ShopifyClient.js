import Client from "shopify-buy"


const client = Client.buildClient({
    storefrontAccessToken: "ea1baba50c81816b5fea3d076cb21a37",
    domain: "demo-dawn-vibha.myshopify.com",
  });


  
export default client