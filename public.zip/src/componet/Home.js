import React from "react"
import { useShopify } from "../action/help/shopify.help"

// eslint-disable-next-line import/no-anonymous-default-export
export default (props) => {
	const { shopDetails } = useShopify()

	return (
		<div>
			<header className="App__header">
				<div className="App__title">
					<h1>{shopDetails.name}</h1>
					<h2>{shopDetails.description}</h2>
				</div>
			</header>
		</div>
	)
}
